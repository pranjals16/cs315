<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">

<HTML <HEAD><TITLE>Site Map</TITLE>

<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">

<META content=noindex name=robots>



<META content="MSHTML 6.00.2800.1106" name=GENERATOR></HEAD>

<BODY text=black link=#0000ff vLink=#0000ff aLink=#0000ff leftmargin="0" topmargin="0" bgcolor = 	"#FCDFFF">

<TABLE cellSpacing=0 cellPadding=20 width="102%" border=0 height="3610">

  <TBODY> 

  <TR>

    <TD valign="top">
<font size="2"><b><a name="top"></a> </b></font>
<DIV>
        <table width="80%" height="219" border="0" align="center" cellpadding="4" cellspacing="4">

 <!--**************************************Search by Student NAME************************************************	  --> 
          <tr> 
            <td height="19">&nbsp;</td>
            <td>&nbsp;</td>
            <td>Search By Student Name</td>
          </tr>

         		   <script language="JavaScript">
  function validateForm2(theForm){
    if(theForm.name.value ==""){
      alert("Enter the name");
      theForm.name.focus();
      return false;
    }

    return true;
  }
  </script>
 

			<tr> 
            <td height="43">&nbsp;</td>
            <td>&nbsp;</td>
            <td  bgcolor="#ADD8E6"><span class="style1"> </span> <form method="POST" action="SearchbyStudentname.php" onsubmit="return validateForm2(this) ;" target="content" class="style1" >
      <font size="2"> </font>
	  <p class="style1">Enter Name </br>
                  <input type="text" name="name"  size=30 maxlength=100></br>

                  <input type="submit" name="submit" value="submit" align="bottom">
    </p>   
				</form></td>
          </tr>
          <tr> 		  
            <td height="19">&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
		  
		  
		  <!--**************************************Search by Student NAME************************************************	  --> 
		  	  
		  
		 <!--**************************************Search by Student Roll Number************************************************	  --> 
		  
		  		    <tr> 
            <td height="19" colspan="3"> <hr size="1"></td>
          </tr>
          <tr> 
            <td height="19">&nbsp;</td>
            <td>&nbsp;</td>
            <td>Search By Student Roll Number</td>
          </tr>

          		  
		   <script language="JavaScript">
  function validateForm1(theForm){
    if(theForm.roll_no.value ==""){
      alert("Enter the roll_no");
      theForm.roll_no.focus();
      return false;
    }

    return true;
  }
  </script>
 

			<tr> 
            <td height="43">&nbsp;</td>
            <td>&nbsp;</td>
            <td  bgcolor="#ADD8E6"><span class="style1"> </span> <form method="POST" action="SearchbyStudentroll_no.php" onsubmit="return validateForm1(this);" target="content" class="style1">
      <font size="2"> </font>
	  <p class="style1">Enter Roll_number </br>
                  <input type="text" name="roll_no"  size=30 maxlength=100></br>

                  <input type="submit" name="submit" value="submit" align="bottom">
    </p>   
				</form></td>
          </tr>
          <tr> 		  
            <td height="19">&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
		  
	<!--**************************************Search by Student Roll Number************************************************	  -->   
		  
	<!--**************************************Search by Student Email_id************************************************	  -->  
		  
		  
		  
		    <tr> 
            <td height="19" colspan="3"> <hr size="1"></td>
          </tr>
          <tr> 
            <td height="19">&nbsp;</td>
            <td>&nbsp;</td>
            <td>Search by Student Email_id</td>
          </tr>
 
		 
		
  

  <script language="JavaScript">
  function validateForm(theForm){
    if(theForm.email_id.value ==""){
      alert("Enter the email_id");
      theForm.email_id.focus();
      return false;
    }

    return true;
  }
  </script>
 

			<tr> 
            <td height="43">&nbsp;</td>
            <td>&nbsp;</td>
            <td  bgcolor="#ADD8E6"><span class="style1"> </span> <form method="POST" action="SearchbyStudentEmail_id.php" onsubmit="return validateForm(this);" target="content" class="style1">
      <font size="2"> </font>
	  <p class="style1">Enter Email_id </br>
                  <input type="text" name="email_id"  size=30 maxlength=100></br>

                  <input type="submit" name="submit" value="submit" align="bottom">
    </p>   
				</form></td>
          </tr>
          <tr> 		  
            <td height="19">&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>

		  
		  
	
		  <!--**************************************Search by Student Email_id************************************************	  -->  
		  
		  <!--**************************************Search by Student phone_number************************************************	  -->
		  
		   <tr> 
            <td height="19" colspan="3"> <hr size="1"></td>
          </tr>
		  
          <tr> 
            <td height="19">&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr> 
            <td height="19">&nbsp;</td>

            <td>&nbsp;</td>
            <td>Search whose number is this?</td>
          </tr>
		  
		    <script language="JavaScript">
  function validateForm3(theForm){
    if(theForm.phone_no.value ==""){
      alert("Enter the Phone No.");
      theForm.phone_no.focus();
      return false;
    }

    return true;
  }
  </script>
 

			<tr> 
            <td height="43">&nbsp;</td>
            <td>&nbsp;</td>
            <td  bgcolor="#ADD8E6"><span class="style1"> </span> <form method="POST" action="SearchbyStudentnumber.php" onsubmit="return validateForm3(this);" target="content" class="style1">
      <font size="2"> </font>
	  <p class="style1">Enter Phone No. </br>
                  <input type="text" name="phone_no"  size=30 maxlength=100></br>

                  <input type="submit" name="submit" value="submit" align="bottom">
    </p>   
				</form></td>
          </tr>
          <tr> 		  
            <td height="19">&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
		  
		  
		  
		  
	   <!--**************************************Search by Student phone_number************************************************	  -->
		  
		    <tr> 
            <td height="19" colspan="3"> <hr size="1"></td>
          </tr>
		  
		  
		  
		  
		
        </table>
      </DIV>

	  
	
	  
	  
	  
	  
      
  </BODY></HTML>

