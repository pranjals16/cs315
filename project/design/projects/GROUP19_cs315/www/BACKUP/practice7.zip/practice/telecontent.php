<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<HTML>

<body background="hero.jpg"> 

<div id="imSite">
<div id="imHeader">
<hr class="imInvisible" />
<div id="imContent">
<!-- Page Content START -->

<HTML>
<BODY text=black vLink=#0000ff aLink=#0000ff link=#0000ff bgColor=white>
</BODY>
</HTML>

<p align="center">

<a href="maintext.php" target="content" class="style1"><h3>Home</h3></a> <br>

<a href="login-form-admin.php" target="content" class="style1"><h3>Login as Admin</h3></a> <br>

<a href="browse1.php" target="content" class="style1"><h3>Student Search</h3></a> <br>

<a href="browse2.php" target="content" class="style1"><h3>Staff Search</h3></a> <br>

<a href="browse3.php" target="content" class="style1"><h3>Important Contacts</h3></a> <br>

<a href="login-form.php" target="content" class="style1"><h3>Student Update</h3></a>  <br>

<a href="login-form-faculty.php" target="content" class="style1"><h3>Staff Update</h3></a> .</p>

<!-- Page Content END -->

<hr />
</body>
</HTML>
