
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">

<form action="desig-output.php" method="post" target="content2">

<select id="numitems" name="numitems">

 <option value="Advanced Centre for Materials Science (ACMS)" selected="selected">Advanced Centre for Materials Science (ACMS) 
</option> 
 <option value="Aerospace Engineering">Aerospace Engineering
</option> 
 <option value="Internal Audit Section ">Internal Audit Section 
</option> 
 <option value="Biological Sciences and Bio Engineering">Biological Sciences and Bio Engineering
</option> 
 <option value="Centre for Development of Technical Education ">Centre for Development of Technical Education 
</option> 
 <option value="Counselling ">Counselling , Head 
</option> 
 <option value="Chemical Engineering">Chemical Engineering , Head 
</option> 
 <option value="Civil Engineering">Civil Engineering, Head 
</option> 
 <option value="Computer Centre">Computer Centre , Head
</option> 
 <option value="Computer Science and Engineering">Computer Science and Engineering, Head 
</option> 
 <option value="Design Programme">Design Programme , Head
</option> 
 <option value="Electrical Engineering">Electrical Engineering , Head 
</option> 
 <option value="Centre for Laser Technology (CELT)">Centre for Laser Technology (CELT) , Head 
</option> 
 <option value="PK Kelkar Library">PK Kelkar Library, Head Head
</option> 
 <option value="Materials and Metallurgical Engineering">Materials and Metallurgical Engineering , Head �
</option> 
 <option value="Mathematics & Statistics">Mathematics & Statistics, Head 
</option> 
 <option value="Materials Science Programme">Materials Science Programme , Head
</option> 
 <option value="Samtel Centre for Display Technology">Samtel Centre for Display Technology , Head 
</option> 
 <option value="Central Store and Purchasing">Central Store and Purchasing, Incharge 
</option> 
 <option value="Registrar's Office">Registrar's Office , Registrar 
</option> 
 <option value="Dean of Academic Affairs , SPGC">Dean of Academic Affairs , SPGC 
</option> 
 <option value="Dean of Academic Affairs , SUGC">Dean of Academic Affairs , SUGC 
</option> 
 <option value="Students' Placement and Career Centre ">Students' Placement and Career Centre 
</option> 
 <option value="Telephone Unit , Chairman">Telephone Unit , Chairman
</option> 
 <option value="Dean of Academic Affairs , Dean">Dean of Academic Affairs , Dean
</option> 
 <option value="Dean of Faculty Affairs , Dean">Dean of Faculty Affairs , Dean 
</option> 
 <option value="Dean Resource, Planning and Generation , Dean">Dean Resource, Planning and Generation , Dean 
</option> 
 <option value="Dean of Student's Affairs , Dean">Dean of Student's Affairs , Dean 
</option> 
 <option value="Research Development and Industrial Consultancy">Research Development and Industrial Consultancy
</option> 
 <option value="Directorate">Directorate
</option> 






</select>

<input type="submit" value="designation" />
</form>
<br />




<?php





?>

</body>
</html>

