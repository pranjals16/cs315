<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr">
<head>
	<title></title>

	<!-- Contents -->
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<meta http-equiv="Content-Language" content="en" />
	<meta http-equiv="last-modified" content="04/04/2009 01:14:28" />
	<meta http-equiv="Content-Type-Script" content="text/javascript" />

	<meta name="description" content="" />
	<meta name="keywords" content="" />

	<!-- Others -->
	<meta name="Generator" content="Incomedia WebSite X5 Evolution 7.0.11 - www.websitex5.com" />
	<meta http-equiv="ImageToolbar" content="False" />
	<meta name="MSSmartTagsPreventParsing" content="True" />

	<!-- Parent -->
	<link rel="sitemap" href="imsitemap.html" title="General Site Map" />

	<!-- Res -->
	<script type="text/javascript" src="res/x5engine.js"></script>
	<link rel="stylesheet" type="text/css" href="res/styles.css" media="screen, print" />
	<link rel="stylesheet" type="text/css" href="res/template.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="res/print.css" media="print" />
	<!--[if lt IE 7]><link rel="stylesheet" type="text/css" href="res/iebehavior.css" media="screen" /><![endif]-->
	<link rel="stylesheet" type="text/css" href="res/home.css" media="screen, print" />
	<link rel="stylesheet" type="text/css" href="res/handheld.css" media="handheld" />

	<link rel="alternate stylesheet" title="High contrast - Accessibility" type="text/css" href="res/accessibility.css" media="screen" />

	<!-- Robots -->
	<meta http-equiv="Expires" content="0" />
	<meta name="Resource-Type" content="document" />
	<meta name="Distribution" content="global" />
	<meta name="Robots" content="index, follow" />
	<meta name="Revisit-After" content="21 days" />
	<meta name="Rating" content="general" />

</head>
<body>
<div id="imSite">
<div id="imHeader">
	<h1></h1>
</div>
<div class="imInvisible">
<hr />
<a href="#imGoToCont" title="Skip the main menu">Go to content</a>
<a name="imGoToMenu"></a>
</div>
<div id="imBody">
	<div id="imMenuMain">

<!-- Menu Content START -->
<p class="imInvisible">Main menu:</p>
<div id="imMnMn">
<ul>
	<li><a href="index.html" title="">Home Page</a></li>
</ul>
</div>
<!-- Menu Content END -->

	</div>
<hr class="imInvisible" />
<a name="imGoToCont"></a>
	<div id="imContent">

<!-- Page Content START -->
<div id="imToolTip"></div>
<div id="imPage">

<div id="imCel7_00">
<div id="imCel7_00_Cont">
	<div id="imObj7_00">
  <p align="center">&nbsp;
	</h4>
  <p align="center">&nbsp;<a href="login-form-admin.php">login as admin</a> .</p>

	  
	
	  </p>
	</div>
</div>
</div>

<div id="imCel7_04">
<div id="imCel7_04_Cont">
	<div id="imObj7_04">
<HTML><HEAD>

</HEAD>

<BODY text=black vLink=#0000ff aLink=#0000ff link=#0000ff bgColor=white>

<TABLE cellSpacing=0 cellPadding=20 width="100%" border=0>

  <TBODY>

  <TR>


       
        <p align="justify"> <font size="2"><strong><font face="Verdana, Arial, Helvetica, sans-serif">New prefix (Tata-indicom and Reliance connectivity) for telephones</font></strong></font></p>
        <blockquote>
          <p align="justify"><font size="2"><font face="Verdana, Arial, Helvetica, sans-serif">          The new prefix for reaching IITK phones from outside is now functional. For example to reach 7210 from outside you can dial </font></font></p>

          <p align="justify"><font size="2"><font face="Verdana, Arial, Helvetica, sans-serif">+91-512-679-7210 (via Tata-indicom route) <br>

+91-512-392-7210 (via Reliance route) <br>
+91-512-259-7210 (via BSNL route) </font></font></p>
          <p align="justify"><font size="2"><font face="Verdana, Arial, Helvetica, sans-serif"> Please note new prefix <em><font color="#003399">392 allows the calls to come via Reliance route</font></em> and <font color="#003399"><em>679 allows the calls to come via Tata-indicom route</em></font>. All your friends having Reliance and Tata-Indicom phone  can make cheaper calls to you if they have subscribed to on-net call packages using the 392 and 679 prefix.</font></font></p>

          <p align="justify">  <font size="2" face="Verdana, Arial, Helvetica, sans-serif">Persons calling 
from outside can now take benefit of on-net call package by using 
appropriate route for calling campus phones, depending upon their 
telephone operator.
For outgoing, you will be seeing appropriate number on caller id depending 
on through which call is routed to outside world. </font><br>

</p>
        </blockquote>        <p align="justify"> <font size="2"><strong><font color="#990066" face="Verdana, Arial, Helvetica, sans-serif">Changes in the Access codes for Telephone Exchange </font></strong></font></p>
        <blockquote>
          <p align="justify"> <font size="2" face="Verdana, Arial, Helvetica, sans-serif"><em><font color="#9933CC">The 
            access code "20" is now abandoned. </font></em><br>

              <strong>The access codes are as follows </strong></font></p>
          <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#000066">users with ISD acccess can make</font></strong></font></p>

          <blockquote>
            <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> ISD calls by dialling access code "0" <br>
STD and local calls including mobiles by dialling access code "0" <br>
Toll-free number (180 XX...) by dialling access code "0" <br>

Internet dial up to 17XXX... number by dialling access code "0" <br>
</font></p>
          </blockquote>
          <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#000066">users with STD access can make </font></strong></font></p>

          <blockquote>
            <p align="justify">STD and local calls including mobiles by dialling access code "0" <br>
Toll-free number (180 XX...) by dialling access code "0" <br>
Internet dial up to 17XXX... number by dialling access code "0" <br>

</p>
          </blockquote>
          <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#000066">users with local call with 95 and local mobile dialling access </font></strong></font></p>
          <blockquote>

            <p align="justify"> Local call with 95 and local mobile dialling using access code "0"&nbsp; <br>
Toll-free number (180 XX...) by dialling access code "0" <br>
Internet dial up to 17XXX... number by dialling access code "0" </p>

          </blockquote>
          <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#000066">users with local call *without* 95 and local mobile dialling access </font></strong></font></p>
          <blockquote>
            <p align="justify"> Local call within Kanpur (area withing 0512 STD code) using access code "0" <br>

Toll-free number (180 XX...) by dialling access code "0" <br>
Internet dial up to 17XXX... number by dialling access code "0" <br>
</p>

          </blockquote>
        </blockquote></TD>
  </TR>
  </TBODY>
</TABLE></BODY></HTML>


	</div>
</div>
</div>

<div id="imCel7_01">

<div id="imCel7_01_Cont">
	<div id="imObj7_01">
 <p align="center">&nbsp;
	</h4>
  <p align="center">&nbsp;<a href="browse1.php">Student Search</a> .</p>
	  
	
	  </p>

	</div>

</div>
</div>

<div id="imCel7_02">
<div id="imCel7_02_Cont">
	<div id="imObj7_02">
 <p align="center">&nbsp;
	</h4>
  <p align="center">&nbsp;<a href="browse2.php">Staff Search</a> .</p>
	  
	
	  </p>

	</div>
</div>
</div>

<div id="imCel7_03">
<div id="imCel7_03_Cont">
	<div id="imObj7_03">

	  
	  <p align="center">&nbsp;
	</h4>
  <p align="center">&nbsp;<a href="login-form.php">Click here to update your database</a> .</p>

	  
	
	  </p>
	  
	</div>
</div>
</div>

</div>

<!-- Page Content END -->

	</div>
	<div id="imFooter">
		<hr class="imInvisible" />

		<span id="imFooter_L"></span>
		<span id="imFooter_R"></span>
		<br class="imClear" />
	</div>
</div>
</div>
<div class="imInvisible">
<hr />
<a href="#imGoToCont" title="Read this page again">Back to content</a> | <a href="#imGoToMenu" title="Read this page again">Back to main menu</a>

</div>

<div id="imZIBackg" onclick="imZIHide()" onkeypress="imZIHide()"></div>
</body>
</html>
