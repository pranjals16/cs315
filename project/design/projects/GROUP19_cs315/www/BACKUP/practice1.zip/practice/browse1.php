<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">

<HTML <HEAD><TITLE>Site Map</TITLE>

<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">

<META content=noindex name=robots>



<META content="MSHTML 6.00.2800.1106" name=GENERATOR></HEAD>

<BODY text=black link=#0000ff vLink=#0000ff aLink=#0000ff leftmargin="0" topmargin="0">

<TABLE cellSpacing=0 cellPadding=20 width="102%" border=0 height="3610">

  <TBODY> 

  <TR>

    <TD valign="top">
<font size="2"><b><a name="top"></a> </b></font>
<DIV>
        <table width="80%" height="219" border="0" align="center" cellpadding="4" cellspacing="4">
          <tr> 
            <td height="19" colspan="2">&nbsp;</td>
            <td height="19" bgcolor="#F1E4D8">Telephone Directory IITK </td>

          </tr>
          <tr> 
            <td height="19" colspan="3"> <hr size="1"></td>
          </tr>
          <tr> 
            <td height="19">&nbsp;</td>
            <td>&nbsp;</td>
            <td>Search Student Name</td>
          </tr>

          <tr> 
            <td height="43">&nbsp;</td>
            <td>
            <td bgcolor="#F1E4D8"> <form style="MARGIN-BOTTOM: 5px" name=findform 
      onSubmit="javascript: return isNotNull(this.keyword.value)" 
      action=C:\wamp\www\practice\queryno1.php method=GET target="content" 
      alt="Search">
                <p> 
                  <input class=textA id=keyword2 onClick="javascript: document.findform.keyword.value ='';isUserInput=true;" 
      size=30 value="" name=keyword>
             <!--     <select onkeydown=javascript:callSubmit(document.findform.keyword.value,findform,event.keyCode) 
      onChange="javascript: setFormValues(document.findform,document.findform.category.value)" 
      size=1 name=category>
                    <option value=All selected>Faculty or Staff or Student</option> 
                  </select>
		-->
                  <a  onClick="javascript: return isNotNull(document.findform.keyword.value)" 
      href="javascript:document.findform.submit()"><img height=20 alt="Search" src="http://www.iitk.ac.in/tel/mainpage/srch.jpg" width=21 align=absMiddle border=0></a></p>
              </form></td>
          </tr>
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		    <tr> 
            <td height="19" colspan="3"> <hr size="1"></td>
          </tr>
          <tr> 
            <td height="19">&nbsp;</td>
            <td>&nbsp;</td>
            <td>Search By Student Roll Number</td>
          </tr>

          <tr> 
            <td height="43">&nbsp;</td>
            <td>
            <td bgcolor="#F1E4D8"> <form style="MARGIN-BOTTOM: 5px" name=findform 
      onSubmit="javascript: return isNotNull(this.keyword.value)" 
      action=http://telephone.iitk.ac.in/alpha/phone/baaSearch.php method=GET target="content" 
      alt="Search">
                <p> 
                  <input class=textA id=keyword2 onClick="javascript: document.findform.keyword.value ='';isUserInput=true;" 
      size=30 value="" name=keyword>
            <!--      <select onkeydown=javascript:callSubmit(document.findform.keyword.value,findform,event.keyCode) 
      onChange="javascript: setFormValues(document.findform,document.findform.category.value)" 
      size=1 name=category>
                    <option value=All selected>Student</option>
                  </select>
		-->
                  <a  onClick="javascript: return isNotNull(document.findform.keyword.value)" 
      href="javascript:document.findform.submit()"><img height=20 alt="Search" src="http://www.iitk.ac.in/tel/mainpage/srch.jpg" width=21 align=absMiddle border=0></a></p>
              </form></td>
          </tr>
		  
		  
		  
		  
		  
		  
		  
		  
		  
		    <tr> 
            <td height="19" colspan="3"> <hr size="1"></td>
          </tr>
          <tr> 
            <td height="19">&nbsp;</td>
            <td>&nbsp;</td>
            <td>Search by Student Email_id</td>
          </tr>

          <tr> 
            <td height="43">&nbsp;</td>
            <td>
            <td bgcolor="#F1E4D8"> <form style="MARGIN-BOTTOM: 5px" name=findform 
      onSubmit="javascript: return isNotNull(this.keyword.value)" 
      action=http://telephone.iitk.ac.in/alpha/phone/baaSearch.php method=GET target="content" 
      alt="Search">
                <p> 
                  <input class=textA id=keyword2 onClick="javascript: document.findform.keyword.value ='';isUserInput=true;" 
      size=30 value="" name=keyword>
             <!--     <select onkeydown=javascript:callSubmit(document.findform.keyword.value,findform,event.keyCode) 
      onChange="javascript: setFormValues(document.findform,document.findform.category.value)" 
      size=1 name=category>
                    <option value=All selected>Faculty or Staff or Student</option>
                  </select>
		-->
                  <a  onClick="javascript: return isNotNull(document.findform.keyword.value)" 
      href="javascript:document.findform.submit()"><img height=20 alt="Search" src="http://www.iitk.ac.in/tel/mainpage/srch.jpg" width=21 align=absMiddle border=0></a></p>
              </form></td>
          </tr>
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
          <tr> 
            <td height="19">&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr> 
            <td height="19">&nbsp;</td>

            <td>&nbsp;</td>
            <td>Search whose number is this?</td>
          </tr>
          <tr> 
            <td height="43">&nbsp;</td>
            <td>&nbsp;</td>
            <td  bgcolor="#F1E4D8"><span class="style1"> </span> <form action="http://telephone.iitk.ac.in/alpha/phone/phone.php"  method="post" name="mainFrame" target="content" class="style1" >
                <p class="style1">Enter Phone No. 
                  <input type="text" name="tInput"  size=30 maxlength=100>

                  <input type="submit" value="Search Now" name="Continue" align="bottom">
                </p>
              </form></td>
          </tr>
          <tr> 
		  
		  
		  
		  
		  
		  
		  
		  
		  
            <td height="19">&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>

		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
          <tr> 
            <td height="19" colspan="3"> <hr size="1"></td>
          </tr>
        </table>
      </DIV>

	  
	  <p align="center">&nbsp;
	</h4>
  <p align="center">&nbsp;<a href="login-form.php">Click here to update your database</a> .</p>
	  
	
	  </p>
	  
	  
	  
	  
	  
	  
      
  </BODY></HTML>

