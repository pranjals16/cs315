<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">

<HTML <HEAD><TITLE>Site Map</TITLE>

<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">

<META content=noindex name=robots>



<META content="MSHTML 6.00.2800.1106" name=GENERATOR></HEAD>

<BODY text=black link=#0000ff vLink=#0000ff aLink=#0000ff leftmargin="0" topmargin="0" bgcolor = 	"#FCDFFF">

<TABLE cellSpacing=0 cellPadding=20 width="102%" border=0 height="3610">

  <TBODY> 

  <TR>

    <TD valign="top">
<font size="2"><b><a name="top"></a> </b></font>
<DIV>
        <table width="80%" height="219" border="0" align="center" cellpadding="4" cellspacing="4">

 <!--**************************************Search by Staff NAME************************************************	  --> 
          <tr> 
            <td height="19">&nbsp;</td>
            <td>&nbsp;</td>
            <td>Search By Faculty or Staff Name</td>
          </tr>

         		   <script language="JavaScript">
  function validateForm8(theForm){
    if(theForm.name.value ==""){
      alert("Enter the name");
      theForm.name.focus();
      return false;
    }

    return true;
  }
  </script>
 

			<tr> 
            <td height="43">&nbsp;</td>
            <td>&nbsp;</td>
            <td  bgcolor="#ADD8E6"><span class="style1"> </span> <form method="POST" action="SearchbyStaffname_no.php" onsubmit="return validateForm8(this);" target="content" class="style1">
      <font size="2"> </font>
	  <p class="style1">Enter Name </br>
                  <input type="text" name="name"  size=30 maxlength=100></br>

                  <input type="submit" name="submit" value="submit" align="bottom">
    </p>   
				</form></td>
          </tr>
          <tr> 		  
            <td height="19">&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
		  
		  
		  <!--**************************************Search by Staff NAME************************************************	  --> 
		  	  
		  
		
 

		  
	<!--**************************************Search by Staff Email_id************************************************	  -->  
		  
		  
		  
		    <tr> 
            <td height="19" colspan="3"> <hr size="1"></td>
          </tr>
          <tr> 
            <td height="19">&nbsp;</td>
            <td>&nbsp;</td>
            <td>Search by Faculty or Staff Email_id</td>
          </tr>
 
		 
		
  

  <script language="JavaScript">
  function validateForm6(theForm){
    if(theForm.email_id.value ==""){
      alert("Enter the email_id");
      theForm.email_id.focus();
      return false;
    }

    return true;
  }
  </script>
 

			<tr> 
            <td height="43">&nbsp;</td>
            <td>&nbsp;</td>
            <td  bgcolor="#ADD8E6"><span class="style1"> </span> <form method="POST" action="SearchbyStaffEmail_id.php" onsubmit="return validateForm6(this);" target="content" class="style1">
      <font size="2"> </font>
	  <p class="style1">Enter Email_id </br>
                  <input type="text" name="email_id"  size=30 maxlength=100></br>

                  <input type="submit" name="submit" value="submit" align="bottom">
    </p>   
				</form></td>
          </tr>
          <tr> 		  
            <td height="19">&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>

		  
		  
	
		  <!--**************************************Search by Staff Email_id************************************************	  -->  
		  
		  <!--**************************************Search by Staff phone_number************************************************	  -->
		  
		  
		    <tr> 
            <td height="19" colspan="3"> <hr size="1"></td>
          </tr>
          <tr> 
            <td height="19">&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr> 
            <td height="19">&nbsp;</td>

            <td>&nbsp;</td>
            <td>Search whose number is this?</td>
          </tr>
		  
		    <script language="JavaScript">
  function validateForm7(theForm){
    if(theForm.phone_no.value ==""){
      alert("Enter the Phone No.");
      theForm.phone_no.focus();
      return false;
    }

    return true;
  }
  </script>
 

			<tr> 
            <td height="43">&nbsp;</td>
            <td>&nbsp;</td>
            <td  bgcolor="#ADD8E6"><span class="style1"> </span> <form method="POST" action="SearchbyStaffphone_no.php" onsubmit="return validateForm7(this);" target="content" class="style1">
      <font size="2"> </font>
	  <p class="style1">Enter Phone No. </br>
                  <input type="text" name="phone_no"  size=30 maxlength=100></br>

                  <input type="submit" name="submit" value="submit" align="bottom">
    </p>   
				</form></td>
          </tr>
          <tr> 		  
            <td height="19">&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
		  
		  
		  
		  
	   <!--**************************************Search by Student phone_number************************************************	  -->
		  
		  
		  
		  
		  
		  
		  
          <tr> 
            <td height="19" colspan="3"> <hr size="1"></td>
          </tr>
        </table>
      </DIV>

	
	  
	  
	  
	  
      
  </BODY></HTML>

