<CENTER>
<body bgColor="#008000"> 
<p  <font size="2"><strong>
<font face="Verdana, Arial, Helvetica, sans-serif">
<H1>WELCOME TO IITK TELEPHONE DIRECTORY</H1>
</font></strong></font></p>
</body>
</CENTER>