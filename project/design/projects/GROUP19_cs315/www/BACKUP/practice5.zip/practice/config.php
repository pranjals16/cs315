<?php
	define('DB_HOST', 'localhost');
    define('DB_USER', 'deepak');
    define('DB_PASSWORD', 'iw2fmyw1');
    define('DB_DATABASE', 'my_db');
?>