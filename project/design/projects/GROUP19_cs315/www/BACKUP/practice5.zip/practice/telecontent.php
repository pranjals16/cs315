<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr">
<head>
	<title></title>

	<!-- Contents -->
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<meta http-equiv="Content-Language" content="en" />
	<meta http-equiv="last-modified" content="04/04/2009 01:14:28" />
	<meta http-equiv="Content-Type-Script" content="text/javascript" />

	<meta name="description" content="" />
	<meta name="keywords" content="" />

	<!-- Others -->
	<meta name="Generator" content="Incomedia WebSite X5 Evolution 7.0.11 - www.websitex5.com" />
	<meta http-equiv="ImageToolbar" content="False" />
	<meta name="MSSmartTagsPreventParsing" content="True" />

	<!-- Parent -->
	<link rel="sitemap" href="imsitemap.html" title="General Site Map" />

	<!-- Res -->
	<script type="text/javascript" src="res/x5engine.js"></script>
	<link rel="stylesheet" type="text/css" href="res/styles.css" media="screen, print" />
	<link rel="stylesheet" type="text/css" href="res/template.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="res/print.css" media="print" />
	<!--[if lt IE 7]><link rel="stylesheet" type="text/css" href="res/iebehavior.css" media="screen" /><![endif]-->
	<link rel="stylesheet" type="text/css" href="res/home.css" media="screen, print" />
	<link rel="stylesheet" type="text/css" href="res/handheld.css" media="handheld" />

	<link rel="alternate stylesheet" title="High contrast - Accessibility" type="text/css" href="res/accessibility.css" media="screen" />

	<!-- Robots -->
	<meta http-equiv="Expires" content="0" />
	<meta name="Resource-Type" content="document" />
	<meta name="Distribution" content="global" />
	<meta name="Robots" content="index, follow" />
	<meta name="Revisit-After" content="21 days" />
	<meta name="Rating" content="general" />

</head>



<body bgColor="#E0FFFF"> 


<div id="imSite">
<div id="imHeader">
	<h1></h1>
</div>

<div id="imBody">
	<div id="imMenuMain">



	</div>
<hr class="imInvisible" />
<a name="imGoToCont"></a>
	<div id="imContent">

<!-- Page Content START -->
<div id="imToolTip"></div>
<div id="imPage">

<div id="imCel7_00">
<div id="imCel7_00_Cont">
	<div id="imObj7_00">
  <p align="center">&nbsp;
	</h4>
  <p align="center">&nbsp;<a href="login-form-admin.php"><h3>login as admin</h3></a> .</p>

	  
	
	  </p>
	</div>
</div>
</div>

<div id="imCel7_04">
<div id="imCel7_04_Cont">
	<div id="imObj7_04">
<HTML><HEAD>

</HEAD>

<BODY text=black vLink=#0000ff aLink=#0000ff link=#0000ff bgColor=white>

</BODY></HTML>


	</div>
</div>
</div>

  <p align="center">&nbsp;<a href="browse1.php"><h3>Student Search</h3></a> .</p>
	  
	
	  </p>

	</div>

</div>
</div>


  <p align="center">&nbsp;<a href="browse2.php"><h3>Staff Search</h3></a> .</p>
	  
	
	  </p>

	
  <p align="center">&nbsp;<a href="login-form.php"><h3>Click here to update your database</h3></a> .</p>

	  
	
	  
	  
	  
	</div>
</div>
</div>

</div>

<!-- Page Content END -->

	</div>
	<div id="imFooter">
		<hr class="imInvisible" />

		<span id="imFooter_L"></span>
		<span id="imFooter_R"></span>
		<br class="imClear" />
	</div>
</div>
</div>
<div class="imInvisible">
<hr />


</div>

<div id="imZIBackg" onclick="imZIHide()" onkeypress="imZIHide()"></div>
</body>
</html>
