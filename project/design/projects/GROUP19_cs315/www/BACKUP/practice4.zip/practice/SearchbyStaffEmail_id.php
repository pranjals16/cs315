

<?php
  
  //Connect to mysql server
	$link = mysql_connect("localhost", "deepak", "iw2fmyw1");
	if(!$link) {
		die('Failed to connect to server: ' . mysql_error());
	}
	//echo "connedted to db!";
	
	//Select database
	$db = mysql_select_db("my_db", $link);
	if(!$db) {
		die("Unable to select database");
	}
  
  $email_id=$_POST["email_id"];
  

  $errormessage = "";

 //$sql="SELECT * FROM staff_phone_number  WHERE staff_phone_number.email_id='$email_id' ";

//WHERE staff_phone_number.email_id='$email_id' 
		//and staff.email_id =  '$email_id' 
  //faculty_fullname_email.email_id = '$email_id' ";

  $sql="SELECT staff.office_address , staff.department, faculty_fullname_email.full_name, staff.email_id, staff.title
FROM staff,  faculty_fullname_email
WHERE faculty_fullname_email.email_id = '$email_id' 
and faculty_fullname_email.email_id = staff.email_id";
 
  $result = mysql_query($sql, $link)  or exit('$sql failed: '.mysql_error()); 
  echo $result;
  while($row = mysql_fetch_array($result))
	{
		print_r($row);
	//echo $row['email_id'];
    //echo $row['mob_number'];

	}
  $sql="SELECT staff_phone_number.phone_number,      
				staff_phone_number.number_type
		
FROM staff_phone_number
	
WHERE staff_phone_number.email_id = '$email_id'";
  
  
  $result = mysql_query($sql, $link)  or exit('$sql failed: '.mysql_error()); 
  echo $result;
  while($row = mysql_fetch_array($result))
	{
		print_r($row);
	//echo $row['email_id'];
    //echo $row['mob_number'];

	}
 
 
  
  
  mysql_close($link);
?>