

<?php
  
  //Connect to mysql server
	$link = mysql_connect("localhost", "deepak", "iw2fmyw1");
	if(!$link) {
		die('Failed to connect to server: ' . mysql_error());
	}
	//echo "connedted to db!";
	
	//Select database
	$db = mysql_select_db("my_db", $link);
	if(!$db) {
		die("Unable to select database");
	}
  
  $name=$_POST["name"];
  

  $errormessage = "";

//$sql="SELECT * FROM student_rollno  WHERE roll_number='$roll_no'";
  /////////////////////////////////////////////
 
  $sql="SELECT student.batch, student.department, fullname_email.full_name,student.email_id,student.roll_no
FROM student,  fullname_email
WHERE fullname_email.full_name like '%$name%' 
and fullname_email.email_id = student.email_id";
 
  $result = mysql_query($sql, $link)  or exit('$sql failed: '.mysql_error()); 
  echo $result;
  while($row = mysql_fetch_array($result))
	{
		print_r($row);
	//echo $row['email_id'];
    //echo $row['mob_number'];

	}
  $sql="SELECT student_mobile.mob_number
FROM fullname_email, 
	student_mobile
	
WHERE fullname_email.full_name like '%$name%'  and fullname_email.email_id = student_mobile.email_id";
  
  
  $result = mysql_query($sql, $link)  or exit('$sql failed: '.mysql_error()); 
  echo $result;
  while($row = mysql_fetch_array($result))
	{
		print_r($row);
	//echo $row['email_id'];
    //echo $row['mob_number'];

	}
 
  
 //////////////////////////////////////////////////// 
  mysql_close($link);
?>