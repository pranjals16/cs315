
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Deletion Successful</title>
<link href="loginmodule.css" rel="stylesheet" type="text/css" />
</head>
<body bgColor="#E0FFFF"> 
<h1>Deletion Successful</h1>
<p><a href="member-index-admin.php">Click here</a> to go to Admin Home.</p>
</body>
</html>
