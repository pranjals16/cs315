<HTML>
<HEAD>
<TITLE>Telephone Directory</TITLE>
</HEAD>
<FRAMESET rows=100,* 
frameSpacing=0 frameBorder=no border=2 bordercolor="#003366">
  <FRAME src="tophead.php" name=banner frameBorder=0 scrolling=auto marginWidth=0 
marginHeight=0 border=0>
  <FRAMESET border=1 cols=33%,*>
    <FRAME id=navigation 
title=Navigation name=navigation 
src="telecontent.php" scrolling=yes>
    <FRAME id=content 
title=TopIC name=content src="maintext.php" 
scrolling=yes>
  </FRAMESET>
</FRAMESET><noframes></noframes>

</HTML>
