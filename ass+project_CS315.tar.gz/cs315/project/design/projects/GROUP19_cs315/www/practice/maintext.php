<HTML><HEAD>

</HEAD>

<BODY text=black vLink=#0000ff aLink=#0000ff link=#0000ff bgColor=#5CB3FF >

<TABLE cellSpacing=0 cellPadding=20 width="100%" border=0>

  <TBODY>

  <TR>

   



        
        <p align="justify"> <font size="2"><strong><font face="Verdana, Arial, Helvetica, sans-serif">New prefix (Tata-indicom and Reliance connectivity) for telephones</font></strong></font></p>
        <blockquote>
          <p align="justify"><font size="2"><font face="Verdana, Arial, Helvetica, sans-serif">          The new prefix for reaching IITK phones from outside is now functional. For example to reach 7210 from outside you can dial </font></font></p>
          <p align="justify"><font size="2"><font face="Verdana, Arial, Helvetica, sans-serif">+91-512-679-7210 (via Tata-indicom route) <br>

+91-512-392-7210 (via Reliance route) <br>
+91-512-259-7210 (via BSNL route) </font></font></p>
          <p align="justify"><font size="2"><font face="Verdana, Arial, Helvetica, sans-serif"> Please note new prefix <em><font color="#003399">392 allows the calls to come via Reliance route</font></em> and <font color="#003399"><em>679 allows the calls to come via Tata-indicom route</em></font>. All your friends having Reliance and Tata-Indicom phone  can make cheaper calls to you if they have subscribed to on-net call packages using the 392 and 679 prefix.</font></font></p>
          <p align="justify">  <font size="2" face="Verdana, Arial, Helvetica, sans-serif">Persons calling 
from outside can now take benefit of on-net call package by using 
appropriate route for calling campus phones, depending upon their 
telephone operator.
For outgoing, you will be seeing appropriate number on caller id depending 
on through which call is routed to outside world. </font><br>

</p>
        </blockquote>        <p align="justify"> <font size="2"><strong><font color="#990066" face="Verdana, Arial, Helvetica, sans-serif">Changes in the Access codes for Telephone Exchange </font></strong></font></p>
        <blockquote>
          <p align="justify"> <font size="2" face="Verdana, Arial, Helvetica, sans-serif"><em><font color="#9933CC">The 
            access code "20" is now abandoned. </font></em><br>
              <strong>The access codes are as follows </strong></font></p>
          <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#000066">users with ISD acccess can make</font></strong></font></p>

          <blockquote>
            <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> ISD calls by dialling access code "0" <br>
STD and local calls including mobiles by dialling access code "0" <br>
Toll-free number (180 XX...) by dialling access code "0" <br>
Internet dial up to 17XXX... number by dialling access code "0" <br>
</font></p>
          </blockquote>
          <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#000066">users with STD access can make </font></strong></font></p>

          <blockquote>
            <p align="justify">STD and local calls including mobiles by dialling access code "0" <br>
Toll-free number (180 XX...) by dialling access code "0" <br>
Internet dial up to 17XXX... number by dialling access code "0" <br>
</p>
          </blockquote>
          <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#000066">users with local call with 95 and local mobile dialling access </font></strong></font></p>
          <blockquote>

            <p align="justify"> Local call with 95 and local mobile dialling using access code "0"&nbsp; <br>
Toll-free number (180 XX...) by dialling access code "0" <br>
Internet dial up to 17XXX... number by dialling access code "0" </p>
          </blockquote>
          <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#000066">users with local call *without* 95 and local mobile dialling access </font></strong></font></p>
          <blockquote>
            <p align="justify"> Local call within Kanpur (area withing 0512 STD code) using access code "0" <br>

Toll-free number (180 XX...) by dialling access code "0" <br>
Internet dial up to 17XXX... number by dialling access code "0" <br>
</p>
          </blockquote>
        </blockquote></TD>
  </TR>
  </TBODY>
</TABLE></BODY></HTML>

