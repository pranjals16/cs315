
<html lang="en" xml:lang="en">





<FRAMESET columns=100,* 
frameSpacing=0 frameBorder=no border=2 bordercolor="#003366">
 
  <FRAMESET border=1 rows=25%,*>
    <FRAME id=navigation 
title=Navigation name=navigation 
src="desig-search.php" >
    <FRAME id=content 
title=TopIC name=content2 src="desig-output.php" 
scrolling=yes>
  </FRAMESET>





</body>
</html>

