<?php echo"<div id='footer' align='center'>| <a href='insert.php'>Contribute</a>| <a href='search.php'>Simple Search</a> |<a href='adv_search.php'>Advanced Search</a> | <a href='logout.php'>Logout</a>|</div>"
?>
